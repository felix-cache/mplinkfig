# mplinkfig

[![PyPI - Version](https://img.shields.io/pypi/v/mplinkfig.svg)](https://pypi.org/project/mplinkfig)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mplinkfig.svg)](https://pypi.org/project/mplinkfig)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install mplinkfig
```

## License

`mplinkfig` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
