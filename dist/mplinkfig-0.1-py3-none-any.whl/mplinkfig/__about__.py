# SPDX-FileCopyrightText: 2024-present felix <felix.cache@umontpellier.fr>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
